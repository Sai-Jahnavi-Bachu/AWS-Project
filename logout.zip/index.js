const AWS = require("aws-sdk");
const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");

const dynamodb = new AWS.DynamoDB.DocumentClient();
const loginDetailsTable = "login_time"; // Update with your table name

exports.handler = async (event) => {
  try {
    console.log("Received event:", JSON.stringify(event));

    const idToken = event.id_token; // Adjust based on your event structure

    // Validate input
    if (!idToken) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "Invalid input" }),
      };
    }

    const email = await getEmailFromIdToken(idToken);

    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: "Email not found in the decoded token",
        }),
      };
    }

    // Find the login record for the given email
    const response = await getLatestLoginRecord(email);

    const items = response.Items || [];

    if (items.length === 0) {
      return {
        statusCode: 401,
        body: JSON.stringify({ message: "User not found or not logged in" }),
      };
    }

    // Get the latest login record
    const loginRecord = items[0];

    // Check if the user is already logged out
    if (loginRecord.logout_time) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: "User already logged out" }),
      };
    }

    // Update the logout timestamp
    const timestamp = new Date().toISOString();
    const loggedInTime = loginRecord.LoggedInTime;
    await updateLogoutTimeInDynamoDB(email, loggedInTime, timestamp);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Logout successful" }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: `Internal Server Error: ${error.message}`,
      }),
    };
  }
};

async function getEmailFromIdToken(idToken) {
  const decodedToken = await verifyToken(idToken);
  return decodedToken.email || null;
}

async function verifyToken(idToken) {
  const jwksUri =
    "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_Yf9N0ULF7/.well-known/jwks.json";

  const client = jwksClient({
    jwksUri: jwksUri,
  });

  return new Promise((resolve, reject) => {
    jwt.verify(
      idToken,
      (header, callback) => {
        client.getSigningKey(header.kid, (err, key) => {
          const signingKey = key.publicKey || key.rsaPublicKey;
          callback(null, signingKey);
        });
      },
      (err, decoded) => {
        if (err) {
          reject(err);
        } else {
          resolve(decoded);
        }
      }
    );
  });
}

async function getLatestLoginRecord(email) {
  return dynamodb
    .query({
      TableName: loginDetailsTable,
      KeyConditionExpression: "Email = :Email",
      ExpressionAttributeValues: {
        ":Email": email,
      },
      ScanIndexForward: false,
      Limit: 1,
    })
    .promise();
}

async function updateLogoutTimeInDynamoDB(email, loggedInTime, timestamp) {
  return dynamodb
    .update({
      TableName: loginDetailsTable,
      Key: {
        Email: email,
        LoggedInTime: loggedInTime,
      },
      UpdateExpression: "SET LoggedOutTime = :timestamp",
      ExpressionAttributeValues: {
        ":timestamp": timestamp,
      },
    })
    .promise();
}
