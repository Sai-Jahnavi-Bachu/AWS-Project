const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const AWS = require("aws-sdk");

const sns = new AWS.SNS();

exports.handler = async (event) => {
  try {
    // Log the entire event object for debugging
    console.log("Received event:", JSON.stringify(event));

    // Get the ID token and feedback from the event
    const feedback = event.feedback;
    const idToken = event.id_token;

    if (!idToken || !feedback) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: "Invalid input. ID token or feedback is missing.",
        }),
      };
    }

    // Decode the ID token
    const decodedToken = await decodeIdToken(idToken);

    // Get the email from the decoded token
    const email = decodedToken.email;

    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({
          message: "Email not found in the decoded token",
        }),
      };
    }

    // Send feedback to SNS
    await publishFeedbackToSNS(email, feedback);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: "Feedback submitted successfully" }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: `Internal Server Error: ${error.message}`,
      }),
    };
  }
};

async function decodeIdToken(idToken) {
  const jwksUri =
    "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_Yf9N0ULF7/.well-known/jwks.json";
  const expectedAudience = "kutfqlinkcik5lp2uc8bk7603";

  return new Promise((resolve, reject) => {
    jwt.verify(
      idToken,
      (header, callback) => {
        // Fetch the public key for verification
        jwksClient({
          jwksUri: jwksUri,
        }).getSigningKey(header.kid, (err, key) => {
          if (err) {
            reject(err);
          } else {
            const signingKey = key.publicKey || key.rsaPublicKey;
            callback(null, signingKey);
          }
        });
      },
      {
        algorithms: ["RS256"],
        audience: expectedAudience,
      },
      (err, decoded) => {
        if (err) {
          reject(err);
        } else {
          resolve(decoded);
        }
      }
    );
  });
}

async function publishFeedbackToSNS(email, feedback) {
  const topicArn = "arn:aws:sns:us-east-2:920381334065:feedback";

  const message = `User Email: ${email}\nFeedback: ${feedback}`;

  await sns
    .publish({
      TopicArn: topicArn,
      Message: message,
      Subject: "New Feedback Received",
    })
    .promise();
}
