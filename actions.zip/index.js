const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB();

exports.handler = async (event) => {
  const idToken = event.id_token;
  const action = event.action; // assuming 'action' is passed in the event
  const jwksUri =
    "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_Yf9N0ULF7/.well-known/jwks.json";
  const expectedAudience = "kutfqlinkcik5lp2uc8bk7603";

  try {
    const decodedToken = await verifyToken(idToken, jwksUri, expectedAudience);

    const email = decodedToken.email || null;

    if (email) {
      // Store email, action, and timestamp in DynamoDB
      await storeInDynamoDB(email, action);

      return {
        statusCode: 200,
        body: JSON.stringify({ email: email, action: action }),
      };
    } else {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Email not found in the decoded token" }),
      };
    }
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: `Something went wrong: ${e.message}` }),
    };
  }
};

async function verifyToken(idToken, jwksUri, expectedAudience) {
  const client = jwksClient({
    jwksUri: jwksUri,
  });

  return new Promise((resolve, reject) => {
    jwt.verify(
      idToken,
      (header, callback) => {
        client.getSigningKey(header.kid, (err, key) => {
          const signingKey = key.publicKey || key.rsaPublicKey;
          callback(null, signingKey);
        });
      },
      {
        algorithms: ["RS256"],
        audience: expectedAudience,
      },
      (err, decoded) => {
        if (err) {
          reject(err);
        } else {
          resolve(decoded);
        }
      }
    );
  });
}

async function storeInDynamoDB(email, action) {
  const currentTime = new Date().toISOString();

  const params = {
    TableName: "useractions", // Adjust the table name as needed
    Item: {
      email: { S: email },
      action: { S: action },
      timestamp: { S: currentTime },
    },
  };

  await dynamodb.putItem(params).promise();
}
