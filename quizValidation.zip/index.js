const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");
const AWS = require("aws-sdk");

const dynamodb = new AWS.DynamoDB();
const ses = new AWS.SES(); // Instantiate SES

exports.handler = async (event) => {
  const idToken = event.id_token;
  const quiz_Id = event.quiz_Id;
  const quizAnswers = event.quiz_answers;
  const jwksUri =
    "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_Yf9N0ULF7/.well-known/jwks.json";
  const expectedAudience = "kutfqlinkcik5lp2uc8bk7603";

  try {
    const decodedToken = await verifyToken(idToken, jwksUri, expectedAudience);

    const email = decodedToken.email || null;

    if (email) {
      // Check quiz answers and store in DynamoDB
      const quizId = quiz_Id; // Set the appropriate quiz ID based on your logic
      const score = calculateScore(quizAnswers, quizId);

      // Store email, quiz ID, and score in DynamoDB
      await storeInDynamoDB(email, quizId, score);

      // Send an email with the score
      await sendEmail(email, quizId, score);

      return {
        statusCode: 200,
        body: JSON.stringify({ email: email, quizId: quizId, score: score }),
      };
    } else {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Email not found in the decoded token" }),
      };
    }
  } catch (e) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: `Something went wrong: ${e.message}` }),
    };
  }
};

async function verifyToken(idToken, jwksUri, expectedAudience) {
  const client = jwksClient({
    jwksUri: jwksUri,
  });

  return new Promise((resolve, reject) => {
    jwt.verify(
      idToken,
      (header, callback) => {
        client.getSigningKey(header.kid, (err, key) => {
          const signingKey = key.publicKey || key.rsaPublicKey;
          callback(null, signingKey);
        });
      },
      {
        algorithms: ["RS256"],
        audience: expectedAudience,
      },
      (err, decoded) => {
        if (err) {
          reject(err);
        } else {
          resolve(decoded);
        }
      }
    );
  });
}

function calculateScore(userAnswers, quizId) {
  // Define correct answers based on the quiz ID
  const correctAnswers = {
    quiz1: ["c", "c", "b", "c", "c"],
    quiz2: ["b", "b", "a", "b", "c"],
    quiz3: ["c", "c", "d", "b", "b"],
  };

  // Compare user answers with correct answers
  const score = userAnswers.reduce((count, userAnswer, index) => {
    const correctAnswer = correctAnswers[quizId][index];
    return count + (userAnswer === correctAnswer ? 1 : 0);
  }, 0);

  // Calculate percentage
  const totalQuestions = correctAnswers[quizId].length;
  const scorePercentage = (score / totalQuestions) * 100;

  return scorePercentage;
}

async function storeInDynamoDB(email, quizId, score) {
  const currentTime = new Date().toISOString();

  const params = {
    TableName: "userScores", // Adjust the table name as needed
    Item: {
      email: { S: email },
      quizID: { S: quizId },
      score: { N: score.toString() },
      timestamp: { S: currentTime },
    },
  };

  await dynamodb.putItem(params).promise();
}

async function sendEmail(email, quizId, score) {
  const params = {
    Destination: {
      ToAddresses: [email],
    },
    Message: {
      Body: {
        Text: {
          Data:
            `Your quiz score for ${quizId} is: ${score.toFixed(2)}%\n\n` +
            `Thank you for participating!`,
        },
      },
      Subject: {
        Data: "Quiz Score",
      },
    },
    Source: "saijahnavibachu@gmail.com", // Update with your SES verified email
  };

  await ses.sendEmail(params).promise();
}
